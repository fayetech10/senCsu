package com.example.sencsu.ui.theme

// ==========================================
// Le thème principal de l'application est
// défini dans:  theme/AppTheme.kt → AppTheme()
//
// Ce fichier est conservé comme point d'entrée
// Legacy. Le thème Material 3 complet est
// configuré dans AppTheme avec les couleurs
// de AppColors et la typographie de Type.kt.
// ==========================================